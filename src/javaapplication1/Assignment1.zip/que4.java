/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author 1913083
 */
public class que4 {
    
    public static void main(String[] args) {
        
        float a = 4.5f, I = 1f, j = 2f, k = 3f;
        float answer1, answer2;
        
        answer1 = k / j * (a + 2.3f * I);
        answer2 = j * k + a;
        
        System.out.println("the values are: ");
        System.out.println("k / j * (a + 2.3 * I) = " +answer1);
        System.out.println("j * k + a = " +answer2);
        
    }
    
}
