/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author 1913083
 */
public class que6 {
    
    public static void main(String[] args) {
        
        int k = 5;
         System.out.println(k++);
         System.out.println(++k);
         
    }
    
}
